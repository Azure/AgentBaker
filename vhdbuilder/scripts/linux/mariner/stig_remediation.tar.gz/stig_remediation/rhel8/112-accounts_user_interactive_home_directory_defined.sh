#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 112/364: 'accounts_user_interactive_home_directory_defined'")
(>&2 echo "FIX FOR THIS RULE 'accounts_user_interactive_home_directory_defined' IS MISSING!")
