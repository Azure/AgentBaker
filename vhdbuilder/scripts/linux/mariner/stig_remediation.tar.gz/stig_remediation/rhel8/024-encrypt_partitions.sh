#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 24/364: 'encrypt_partitions'")
(>&2 echo "FIX FOR THIS RULE 'encrypt_partitions' IS MISSING!")
