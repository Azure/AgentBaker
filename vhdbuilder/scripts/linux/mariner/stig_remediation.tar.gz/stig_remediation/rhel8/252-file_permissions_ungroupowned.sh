#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 252/364: 'file_permissions_ungroupowned'")
(>&2 echo "FIX FOR THIS RULE 'file_permissions_ungroupowned' IS MISSING!")
