#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 119/364: 'accounts_umask_interactive_users'")
(>&2 echo "FIX FOR THIS RULE 'accounts_umask_interactive_users' IS MISSING!")
