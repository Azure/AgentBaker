#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 26/364: 'partition_for_tmp'")
(>&2 echo "FIX FOR THIS RULE 'partition_for_tmp' IS MISSING!")
