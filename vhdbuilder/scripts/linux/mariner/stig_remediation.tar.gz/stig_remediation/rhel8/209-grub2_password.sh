#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 209/364: 'grub2_password'")
(>&2 echo "FIX FOR THIS RULE 'grub2_password' IS MISSING!")
