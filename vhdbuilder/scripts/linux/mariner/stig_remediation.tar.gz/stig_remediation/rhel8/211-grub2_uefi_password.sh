#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 211/364: 'grub2_uefi_password'")
(>&2 echo "FIX FOR THIS RULE 'grub2_uefi_password' IS MISSING!")
