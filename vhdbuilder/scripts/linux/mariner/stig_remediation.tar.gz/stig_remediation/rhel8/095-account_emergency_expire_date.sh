#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 95/364: 'account_emergency_expire_date'")
(>&2 echo "FIX FOR THIS RULE 'account_emergency_expire_date' IS MISSING!")
