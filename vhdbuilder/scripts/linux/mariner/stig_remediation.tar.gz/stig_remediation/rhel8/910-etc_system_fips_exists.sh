#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 7/274: 'etc_system_fips_exists'")
(>&2 echo "FIX FOR THIS RULE 'etc_system_fips_exists' IS MISSING!")
