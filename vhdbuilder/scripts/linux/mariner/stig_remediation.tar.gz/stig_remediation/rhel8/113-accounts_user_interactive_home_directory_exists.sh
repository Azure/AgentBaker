#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 113/364: 'accounts_user_interactive_home_directory_exists'")
(>&2 echo "FIX FOR THIS RULE 'accounts_user_interactive_home_directory_exists' IS MISSING!")
