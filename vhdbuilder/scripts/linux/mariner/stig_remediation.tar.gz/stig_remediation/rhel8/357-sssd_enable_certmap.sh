#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 357/364: 'sssd_enable_certmap'")
(>&2 echo "FIX FOR THIS RULE 'sssd_enable_certmap' IS MISSING!")
