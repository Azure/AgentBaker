#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 92/364: 'account_unique_id'")
(>&2 echo "FIX FOR THIS RULE 'account_unique_id' IS MISSING!")
