#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 194/364: 'auditd_audispd_configure_sufficiently_large_partition'")
(>&2 echo "FIX FOR THIS RULE 'auditd_audispd_configure_sufficiently_large_partition' IS MISSING!")
