#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 308/364: 'bios_enable_execution_restrictions'")
(>&2 echo "FIX FOR THIS RULE 'bios_enable_execution_restrictions' IS MISSING!")
