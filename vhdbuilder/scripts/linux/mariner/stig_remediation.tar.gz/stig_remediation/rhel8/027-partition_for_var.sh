#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 27/364: 'partition_for_var'")
(>&2 echo "FIX FOR THIS RULE 'partition_for_var' IS MISSING!")
