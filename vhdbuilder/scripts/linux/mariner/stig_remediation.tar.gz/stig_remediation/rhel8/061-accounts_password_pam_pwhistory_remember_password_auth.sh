#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 61/364: 'accounts_password_pam_pwhistory_remember_password_auth'")
(>&2 echo "FIX FOR THIS RULE 'accounts_password_pam_pwhistory_remember_password_auth' IS MISSING!")
