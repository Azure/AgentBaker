#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 29/364: 'partition_for_var_log_audit'")
(>&2 echo "FIX FOR THIS RULE 'partition_for_var_log_audit' IS MISSING!")
