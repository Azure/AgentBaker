#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 25/364: 'partition_for_home'")
(>&2 echo "FIX FOR THIS RULE 'partition_for_home' IS MISSING!")
