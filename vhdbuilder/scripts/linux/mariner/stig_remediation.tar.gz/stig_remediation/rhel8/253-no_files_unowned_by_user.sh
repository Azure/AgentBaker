#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 253/364: 'no_files_unowned_by_user'")
(>&2 echo "FIX FOR THIS RULE 'no_files_unowned_by_user' IS MISSING!")
