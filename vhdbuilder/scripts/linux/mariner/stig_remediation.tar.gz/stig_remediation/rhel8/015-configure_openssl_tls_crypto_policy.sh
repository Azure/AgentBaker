#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 15/364: 'configure_openssl_tls_crypto_policy'")
(>&2 echo "FIX FOR THIS RULE 'configure_openssl_tls_crypto_policy' IS MISSING!")
