#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 39/364: 'sudo_restrict_privilege_elevation_to_authorized'")
(>&2 echo "FIX FOR THIS RULE 'sudo_restrict_privilege_elevation_to_authorized' IS MISSING!")
