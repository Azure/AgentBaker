#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 111/364: 'accounts_user_home_paths_only'")
(>&2 echo "FIX FOR THIS RULE 'accounts_user_home_paths_only' IS MISSING!")
