#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 22/364: 'package_mcafeetp_installed'")
(>&2 echo "FIX FOR THIS RULE 'package_mcafeetp_installed' IS MISSING!")
