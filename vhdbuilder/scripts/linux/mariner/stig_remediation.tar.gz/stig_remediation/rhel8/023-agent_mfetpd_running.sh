#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 23/364: 'agent_mfetpd_running'")
(>&2 echo "FIX FOR THIS RULE 'agent_mfetpd_running' IS MISSING!")
