#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 210/364: 'grub2_uefi_admin_username'")
(>&2 echo "FIX FOR THIS RULE 'grub2_uefi_admin_username' IS MISSING!")
