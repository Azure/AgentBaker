#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 110/364: 'accounts_user_dot_no_world_writable_programs'")
(>&2 echo "FIX FOR THIS RULE 'accounts_user_dot_no_world_writable_programs' IS MISSING!")
