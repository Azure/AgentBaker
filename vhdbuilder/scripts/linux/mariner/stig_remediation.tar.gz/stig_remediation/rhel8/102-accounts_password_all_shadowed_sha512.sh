#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 102/364: 'accounts_password_all_shadowed_sha512'")
(>&2 echo "FIX FOR THIS RULE 'accounts_password_all_shadowed_sha512' IS MISSING!")
