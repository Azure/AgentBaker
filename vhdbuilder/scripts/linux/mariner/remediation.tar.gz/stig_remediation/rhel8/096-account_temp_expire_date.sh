#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 96/364: 'account_temp_expire_date'")
(>&2 echo "FIX FOR THIS RULE 'account_temp_expire_date' IS MISSING!")
