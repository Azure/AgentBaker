#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 222/364: 'network_sniffer_disabled'")
(>&2 echo "FIX FOR THIS RULE 'network_sniffer_disabled' IS MISSING!")
