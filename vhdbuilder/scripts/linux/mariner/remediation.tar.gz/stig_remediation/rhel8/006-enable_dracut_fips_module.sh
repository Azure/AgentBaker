#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 6/364: 'enable_dracut_fips_module'")
(>&2 echo "FIX FOR THIS RULE 'enable_dracut_fips_module' IS MISSING!")
