#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 208/364: 'grub2_admin_username'")
(>&2 echo "FIX FOR THIS RULE 'grub2_admin_username' IS MISSING!")
