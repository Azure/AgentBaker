#!/usr/bin/env bash
set -e
(>&2 echo "Remediating rule 21/364: 'installed_OS_is_vendor_supported'")
(>&2 echo "FIX FOR THIS RULE 'installed_OS_is_vendor_supported' IS MISSING!")
